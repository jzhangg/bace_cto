/* global fieldProperties, setAnswer, getPluginParameter, goToNextField, clearAnswer, setMetaData, getPluginParameter */

// Store current answer from fieldProperties
const current_answer = fieldProperties.CURRENT_ANSWER;

// Initialize dictionary that can store ultimate result.
const result_dict = {
    result: ''
};

/////////////////////////////////
// Required Plug-in Parameters //
/////////////////////////////////

const unique_profile_id = getPluginParameter("unique_profile_id");
const final_question = getPluginParameter("final_question") || 0; // Defaults to not being the final question.
const var1_label = getPluginParameter("var1_label");
const var1_pre_a = getPluginParameter("var1_pre_a");
const var1_pre_b = getPluginParameter("var1_pre_b");
const var2_label = getPluginParameter("var2_label");
const var2_pre_a = getPluginParameter("var2_pre_a");
const var2_pre_b = getPluginParameter("var2_pre_b");

/////////////////////////////////
// Optional Plug-in Parameters //
/////////////////////////////////

// DEFAULTS
var n_options_default = 2;
var split_to_rows_default = "|";
var split_to_vars_default = ":";
var buttons_per_row_default = 3;
var button_label_default = "Choice";
var profile_enumerator_default = "number"; // "number" or "letter". Defaults to "number"
var loading_message_default = "Your choice scenario is loading.\nWe appreciate your patience.";
var answers_default = "0,1";

// Assign Colors
var DARK_GREY = '#919492'
var LIGHT_GREY = '#dbdcdc'
var GREEN = '#4caf50'
var BLUE = '#008cba'
var RED = '#fe0000'

// Load in values
const split_to_rows = getPluginParameter("split_to_rows") || split_to_rows_default;
const split_to_vars = getPluginParameter("split_to_vars") || split_to_vars_default;
const n_options = getPluginParameter("n_options") || n_options_default;
const buttons_per_row = getPluginParameter("buttons_per_row") || buttons_per_row_default;
const button_label = getPluginParameter("button_label") || button_label_default;
const profile_enumerator = getPluginParameter("profile_enumerator") || profile_enumerator_default;
const loading_message = getPluginParameter("loading_message") || loading_message_default;

// Get answers parameters then store as array.
let answers_full = getPluginParameter("answers") || answers_default;

console.log('answers')
console.log(answers_full);

const answers = answers_full.split(',');
console.log(answers);

/////////////////////////////////
/////////// FUNCTIONS ///////////
/////////////////////////////////

function addAnswerButtons(n_options = n_options_default, buttons_per_row = buttons_per_row_default, button_label = button_label_default, profile_enumerator = profile_enumerator_default) {

    // Require at least two buttons
    if (!Number.isInteger(n_options) || n_options < 2) {
        n_options = 2;
      }

    // Get table with answers button and clear existing content.
    const table = document.getElementById('answerButtonsTable');
    table.innerHTML = '';

    let row = table.insertRow(); // Create a new row

    for (let i = 1; i <= n_options; i++) {
      const cell = row.insertCell(); // Create a new cell

      if (profile_enumerator === 'letter') {
          enumerator = String.fromCharCode(65 + i - 1); // Use letters for headers (A, B, C, ...)
      } else {
        enumerator = i; // Use numbers for headers (1, 2, 3, ...)
      }

      const button = document.createElement('button');
      button.id = `button${i}`;
      button.innerHTML = `${button_label} ${enumerator}`;
      button.className = 'button';

      button.onclick = function() { eval(`addResult(answer_index=${i - 1})`); }; // Assuming addResultX functions exist

      cell.appendChild(button);

      if (i % buttons_per_row === 0 && i !== n_options) {
        row = table.insertRow();
      }
    }
  }

function addResult(answer_index) {

    // Use result_dict to access results
    var result = result_dict['result'];
    var answer_to_store = result + answer_index;

    // Fix the button colors
    fixButtonColors(answer_index);
    setAnswer(answer_to_store);
}

// Function to fix button colors on click.
function fixButtonColors(answer_index, alreadyAnswered=false) {

    // Get all buttons
    const buttons = document.querySelectorAll('#answerButtonsTable button');

    // Set Colors
    var selectedColor = (alreadyAnswered) ? DARK_GREY : GREEN;
    var unselectedColor = (alreadyAnswered) ? LIGHT_GREY : BLUE;

    buttons.forEach((button, i) => {
        button.style.backgroundColor = (i == answer_index) ? selectedColor : unselectedColor;
    })

}



// Function to create and display a table with dynamic headers based on the profile enumerator
function createTable(table_id, table_components, button_label=button_label_default, profile_enumerator = profile_enumerator_default) {

    // Split the input data into rows
    const rows = table_components.split(split_to_rows);
    // Create the table element
    const table = document.createElement('table');
    table.id = table_id;
    table.className = "bace_table";

    // Return if there are no rows to display
    if (rows.length === 0) {
      return;
    }

    // Determine the number of profiles (columns) based on the first row
    const firstRowValues = rows[0].split(split_to_vars);
    const numProfiles = firstRowValues.length;

    // Create the table header with the appropriate number of profile columns
    const headerRow = document.createElement('tr');
    headerRow.innerHTML += '<th></th>'; // Create an empty header cell for the first column

    // Loop through the number of profiles to create header cells
    for (let i = 1; i < numProfiles; i++) {
        let headerContent;

        if (profile_enumerator==null){

            headerRow.innerHTML += `<th>${button_label}</th>`;

        } else {
            if (profile_enumerator === 'letter'){
                headerContent = String.fromCharCode(65 + i - 1); // Use letters for headers (A, B, C, ...)
            } else {
                headerContent = i; // Use numbers for headers (1, 2, 3, ...)
            }
            headerRow.innerHTML += `<th>${button_label} ${headerContent}</th>`;
        }


    }

    // Append the header row to the table
    table.appendChild(headerRow);

    // Loop through each row of data
    for (const rowData of rows) {
        const rowValues = rowData.split(split_to_vars);
        const row = document.createElement('tr');

        // Check if each row is empty and has the correct number of columns
        if (rowValues.length !== numProfiles) {
            console.error(`Row does not have expected number of columns.\nRow Data: ${rowData}`);
            continue; // Skip rows with incorrect number of columns
        }

        // Create cells for each value in the row
        for (const value of rowValues) {
            const cell = document.createElement('td');
            cell.innerHTML = value;
            row.appendChild(cell);
        }

        // Append the row to the table
        table.appendChild(row);
    }

    // Append the completed table to the container
    var bace_container = document.getElementById('bace_container');
    bace_container.appendChild(table);
}

// Function to change button status
function disableButtons() {
    const buttons = document.querySelectorAll('#answerButtonsTable button'); // Get all buttons
    buttons.forEach((button, i) => { button.disabled = true; })
}

function enableButtons() {
    const buttons = document.querySelectorAll('#answerButtonsTable button'); // Get all buttons
    buttons.forEach((button, i) => { button.disabled = false; })
}


////////////////////////////////
///////// BACE QUERIES /////////
////////////////////////////////

// Queries API to (update answer history) and select new designs
// Should query the /surveyCTO route
function getNextDesign(design, n_options, buttons_per_row, button_label, profile_enumerator) {

  try {
          // Delete loading message
          deleteLoadingMessage();
          // Log design
          console.log(design);

          // Update result dictionary with the new design
          result_dict['result'] = design;

          // Add answer buttons and disable them initially
          addAnswerButtons(n_options, buttons_per_row, button_label, profile_enumerator);
          disableButtons();

          // Create the table with the new design
          createTable('bace_table', design, button_label, profile_enumerator);

          // Re-enable buttons after setting up the table
          enableButtons();
      } catch (error) {
          // Log any errors that occur
          console.error('Error:', error);
      }

}





// Functions to Add/Delete the loading symbol
const loadingSymbolDivId = "loadingSymbolDiv";

function addLoadingMessage(message=loading_message, id=loadingSymbolDivId){

    var loadingDiv = document.getElementById(loadingSymbolDivId);
    loadingDiv.innerHTML = message + "<div class='loading-symbol'></div>"

}

function deleteLoadingMessage(id=loadingSymbolDivId) {
    //document.getElementById(id).style.display = 'none';
    document.getElementById('loadingScreen').style.display = 'none';
    document.getElementById('mainContent').style.display = 'block';
}

////////////////////////////////////////////
/////         Application Logic        /////
////////////////////////////////////////////

// Check if current answer already exists.
var already_answered = current_answer != null;

var this_profile_enumerator = (!final_question) ? profile_enumerator : null;
var this_button_label = (!final_question) ? button_label : "Estimates";

var pre_design = var1_label+split_to_vars+var1_pre_a+split_to_vars+var1_pre_b+split_to_rows
                  +var2_label+split_to_vars+var2_pre_a+split_to_vars+var2_pre_b+split_to_rows;

//addLoadingMessage();

const header = {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
};

const exampleOutput = {
  "output": "Choice 1:Description 1|Choice 2:Description 2|Choice 3:Description 3"
};



if (already_answered) {

    console.log('Already answered. Creating from previous.')

    // Render table from previous answer.
    createTable("bace_table", current_answer, this_button_label, this_profile_enumerator);
    deleteLoadingMessage();

    // Add answer choices
    if (!final_question){

        console.log('Not final question. Adding answer buttons.');

        // Get previous answer choice. (Final element after splitting by `split_to_rows`)
        var answer_split = current_answer.split(split_to_rows);
        var selected_answer_index = answer_split[answer_split.length - 1];

        // Add answer buttons and disable them.
        addAnswerButtons(n_options, buttons_per_row, button_label, profile_enumerator);
        disableButtons();

        // Fix button colors;
        fixButtonColors(selected_answer_index, already_answered);

    }

}
else {

    console.log('New question. Displaying request_data...');

    if (!final_question){
        console.log('Getting next design.');
        getNextDesign(pre_design, n_options, buttons_per_row, this_button_label, this_profile_enumerator);
    }

}
